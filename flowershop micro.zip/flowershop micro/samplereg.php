<html>
<head>
	
<link rel="stylesheet" type="text/css" href="samplereg.css"> 
<style>
body
{
background-size: 100%;
}

{
	width: 80%;
	height:20%;
} 

h1{color: blueviolet;}
.center
{
margin: auto;
width: 50%;
border: 3px solid green;
padding:10px;
}
div
{
	max-width:500px;
	height:100px;

}
input[type=text]
{
	width:50%;
	padding: 10px 15px;
	margin: 5px 0;
	border: 2px solid blueviolet;
	border-radius: 4px;
}
input[type=password]
{
width:50%;
	padding: 10px 15px;
	margin: 5px 0;
	border: 2px solid blueviolet;
	border-radius: 4px;	
}
</style>
	
<script>  
function validateform(){  
var name=document.myform.name.value; 
var address=document.myform.address.value; 
var city=document.myform.city.value; 
var district=document.myform.district.value; 
var tel=document.myform.tel.value; 
var email=document.myform.email.value; 
var password=document.myform.password.value;  
  
if (name==null || name==""){  
  alert("Name can't be blank");  
  return false;  
}
 else if (address==null || address==""){  
  alert("address can't be blank");  
  return false;  
}
else if (city==null || city==""){  
  alert("city can't be blank");  
  return false;  
}
else if (district==null || district==""){  
  alert("district can't be blank");  
  return false;  
}
else if (tel==null || tel==""){  
  alert("tel can't be blank");  
  return false;  
}
else if (email==null || email==""){  
  alert("email can't be blank");  
  return false;  
}
else if(password.length<6){  
  alert("Password must be at least 6 characters long.");  
  return false;  
  }  
}  
</script>
</head>
 
<body background="a10.jpeg"> 

<center>
<h1>REGISTER</h1>
	
<form name="myform" method="post" action="connection1.php" onsubmit= "return validateform()" > 
<div >
<input type="text" name="name" placeholder="Enter  your name here..."size="50"  required><br> 
<input type="text" name="address" placeholder="Enter address here.."size="50"required><br>
<input type="text" name="city" placeholder="Enter city here..."size="50"required><br>
<input type="text" name="district" placeholder="Enter district here..."size="50"required><br>
<input type="text"name="tel" placeholder="Enter mobile number here..."size="50"required><br>
<input type="text"  name="email" placeholder="Enter email here..." size="50"required><br>
<input type="password" name="pwd" placeholder="Enter password here..."size="50"required><br>
<input type="password" name="copwd" placeholder="Enter password here..."size="50"required><br>
 
<input type="submit" value="register" name="reg"> <a href="login.php">already have an account?login</a>
</div>

</form> 

</center>
</body>

<?php
	require("connection1.php");
	if(isset($_POST['reg']))
	{
			if($_POST['pwd'] == $_POST['copwd']){


		
			$sql="INSERT INTO register1(name,address,city,district,tel,email,pwd)VALUES ('$_POST[name]','$_POST[address]','$_POST[city]','$_POST[district]','$_POST[tel]','$_POST[email]','$_POST[pwd]')";
			
			

				if( $conn->query($sql)===TRUE )
				{
					
					echo "<script>alert('Registered Successfully')</script>";

					  

				}
				else
				{
					echo "error:" . $sql ."<br>" . $conn->error;
				}

			}else{
				echo "<script>alert('password incorrect')</script>";
			}
			

}
?>
</html>


 
