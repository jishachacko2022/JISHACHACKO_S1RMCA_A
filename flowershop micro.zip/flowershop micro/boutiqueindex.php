<!DOCTYPE html>
<html><head>
	<style type="text/css">
		h1{
			color: violet;
			font: italic;
			font-size: 100px;
			text-align: center;
		}
		h2{
			color:red;
			word-spacing:10px; 
		}
	</style>
</head>

<body bgcolor="blue" >
	<center>
	<h1>BOUTIQUE SHOP
		
    </h1>
    
	<h2>
	<a href="index1.php"><b>shopping page</b></a> 
	
	</h2>
</center>

<?php
?>

</body>
</html>