<html>
<head>
	
		 
<style> 
body{
  width: 50;
  height: 10;

}

h1
{
  color: blue;
  font-size: 60;

}
form
{
  height: 10px;
  width: 5px;
}

</style>
	
<script>  
function validateform(){  
var cardnumber=document.myform.cardnumber.value; 
var month=document.myform.month.value; 
var year=document.myform.year.value; 
var cvv=document.myform.cvv.value; 
 
  
  
if (cardnumber==null || cardnumber==""){  
  alert("cardnumber can't be blank");  
  return false;  
}
 else if (month==null || month==""){  
  alert("month can't be blank");  
  return false;  
}
else if (year==null || year==""){  
  alert("city can't be blank");  
  return false;  
}
else if (cvv==null || cvv==""){  
  alert("cvv can't be blank");  
  return false;  
}

}  
</script>
</head>  
<body bgcolor="skyblue" > 
<center>
	<h1>PAYMENT</h1>
	<div>
<form name="myform" method="post" action="" onsubmit="return validateform()" >  
cardnumber:     <input type="password" name="cardnumber" placeholder="Enter  your cardnumber.."size="50" ><br> 
expiry date:  <input type="text" name="month" placeholder="mm"size="50"><br>
  <input type="text" name="year" placeholder="yyy"size="50"><br>
cvv: <input type="text" name="cvv" placeholder="cvv."size="50"><br>
<input type="submit"value= "pay" name="reg"><a href="homepage1.php"></a><a href="homepage1.php">home</a>


</div>
</center> 
<?php
  require("connection1.php");
  if(isset($_POST['reg']))
  {
      


    
      $sql="INSERT INTO payment(cardnumber,month,year,cvv)VALUES ('$_POST[cardnumber]','$_POST[month]','$_POST[year]','$_POST[cvv]')";
      
      

        if( $conn->query($sql)===TRUE )
        {
          
          echo "<script>alert('Registered Successfully')</script>";

           

        }
        else
        {
          echo "error:" . $sql ."<br>" . $conn->error;
        }

      }else{
        echo "<script>alert('error')</script>";
      }
      


?>
</body>
</html>

 
