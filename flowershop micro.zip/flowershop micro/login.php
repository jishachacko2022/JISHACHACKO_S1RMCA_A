<html>
<head>
	
		<link rel="stylesheet" type="text/css" href="samplereg.css"> 
<style> 
body{text-align:right;

background-size: 100%;
}

h1{color: blueviolet;}
input[type=text]
{
	width:50%;
	padding: 10px 15px;
	margin: 5px 0;
	border: 2px solid blueviolet;
	border-radius: 4px;
}
input[type=password]
{
width:50%;
	padding: 10px 15px;
	margin: 5px 0;
	border: 2px solid blueviolet;
	border-radius: 4px;	
}
</style>
	
<script>  
function validateform(){  
var email=document.myform.email.value; 
var password=document.myform.password.value; 
  
  
if (email==null || email==""){  
  alert("email can't be blank");  
  return false;  
}
 
else if(password.length<6){  
  alert("Password must be at least 6 characters long.");  
  return false;  
  }  
}  
</script>
</head>  
<body background="a6.jpg"> 
<center>
	<h1>LOGIN</h1>
	<div>
<form name="myform" method="post" action="" onsubmit="return validateform()" >  
<input type="text" name="email" placeholder="Enter  your email here..."size="16" required><br> 
<input type="password" name="password" placeholder="Enter password here.."size="16"required><br>

 
<input type="submit" value="login" name="sub">
<a href="samplereg.php">register</a>
<br><br>


</form> 
</div>
</center> 
<?php

  require_once './connection1.php';
  session_start();

  if(isset($_POST['sub'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM register1 WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);
    if($row = mysqli_fetch_assoc($result)){
      $hash = password_verify($password, $row['password']);
      if($hash == false){
        header('Location: ./login.php?invalidPassword');
        exit();
      }elseif($hash == true){
        $_SESSION['fname'] = $row['fname'];
        $_SESSION['email'] = $row['email'];
        header('Location: ./homepage1.php');
        exit();
      }
    }else{
      header('Location: ./login.php?invalidEmail');
      exit();
    }

  }

?>
</body>
</html>


 
